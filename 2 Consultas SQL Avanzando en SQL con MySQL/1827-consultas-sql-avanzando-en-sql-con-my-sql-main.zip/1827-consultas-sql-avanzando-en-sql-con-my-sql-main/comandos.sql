/* En este archivo encontrarás todos los comandos ejecutados en SQL durante el desarrollo del curso de consultas SQL.

Te invitamos a descargar e instalar MySQL de acuerdo con el video 1.2-Preparando el ambiente. */
